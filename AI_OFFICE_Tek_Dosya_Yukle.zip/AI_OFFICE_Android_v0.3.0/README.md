# AI OFFICE Android v0.3.0 (`com.aioffice.mobile`)

Windows bilgisayarda çalışan AI OFFICE koordinasyon sisteminin Android mobil kontrol merkezidir.

## APK Oluşturma Adımları
1. Bu ZIP arşivini çıkarın ve klasörü **Android Studio** (Ladybug / Koala veya üzeri) ile açın.
2. Gradle senkronizasyonunun tamamlanmasını bekleyin.
3. Üst menüden **Build > Build Bundle(s) / APK(s) > Build APK(s)** yolunu izleyin.
4. Çıkan `app-debug.apk` dosyasını telefonunuza aktarıp üzerine dokunduğunuzda *"Bu uygulamayı yüklemek istiyor musunuz?"* kurulum ekranı açılacaktır.
