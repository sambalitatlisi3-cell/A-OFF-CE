"""
AI OFFICE Windows Koordinatör Mobil Köprüsü (v0.3.0 Uyumlu)
Android uygulamasının (com.aioffice.mobile) bağlanacağı REST API sunucusu.
Kurulum: pip install fastapi uvicorn pydantic httpx
Çalıştırma: python ai_office_bridge.py
"""
import os
import uuid
import shutil
from typing import Dict, List, Optional
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
import httpx

API_TOKEN = os.getenv("AI_OFFICE_TOKEN", "")
app = FastAPI(title="AI OFFICE Windows Coordinator Bridge", version="0.3.0")

def verify_auth(authorization: Optional[str]):
    if not API_TOKEN:
        return
    if not authorization or authorization != f"Bearer {API_TOKEN}":
        raise HTTPException(status_code=401, detail="Geçersiz veya eksik Bearer token")

class AgentStateModel(BaseModel):
    id: str
    name: str
    enabled: bool = False
    connected: bool = True
    last_action: str = "Manuel kullanıcı onayı bekleniyor"
    running_task: Optional[str] = None

class ActivationBody(BaseModel):
    enabled: bool
    user_confirmed: bool = False

class CreateTaskBody(BaseModel):
    idempotency_key: str
    title: str
    prompt: str
    agent_id: str
    priority: int = 2

class TaskRecord(BaseModel):
    task_id: str
    idempotency_key: str
    title: str
    prompt: str
    agent_id: str
    priority: int
    status: str
    error_message: Optional[str] = None
    result_summary: Optional[str] = None

AGENTS: Dict[str, AgentStateModel] = {
    "claude_code": AgentStateModel(id="claude_code", name="CLAUDE CODE"),
    "codex": AgentStateModel(id="codex", name="CODEX"),
    "openai": AgentStateModel(id="openai", name="OPENAI"),
}
TASKS_BY_ID: Dict[str, TaskRecord] = {}
IDEMPOTENCY_INDEX: Dict[str, str] = {}

@app.get("/api/v1/status")
def get_status(authorization: Optional[str] = Header(default=None)):
    verify_auth(authorization)
    return {
        "status": "ONLINE",
        "version": "0.3.0",
        "active_agents": sum(1 for a in AGENTS.values() if a.enabled),
        "queued_tasks": sum(1 for t in TASKS_BY_ID.values() if t.status in ("WAITING", "QUEUED", "RUNNING")),
    }

@app.get("/api/v1/agents")
def list_agents(authorization: Optional[str] = Header(default=None)):
    verify_auth(authorization)
    return list(AGENTS.values())

@app.post("/api/v1/agents/{agent_id}/activation")
def set_agent_activation(agent_id: str, body: ActivationBody, authorization: Optional[str] = Header(default=None)):
    verify_auth(authorization)
    if agent_id not in AGENTS:
        raise HTTPException(status_code=404, detail="Ajan bulunamadı")
    if not body.user_confirmed:
        raise HTTPException(status_code=400, detail="Kullanıcı onayı zorunludur")
    agent = AGENTS[agent_id]
    agent.enabled = body.enabled
    agent.last_action = "Mobil kullanıcı onayı ile etkinleştirildi" if body.enabled else "Mobil üzerinden devre dışı bırakıldı"
    return agent

@app.get("/api/v1/tasks")
def list_tasks(authorization: Optional[str] = Header(default=None)):
    verify_auth(authorization)
    return list(TASKS_BY_ID.values())

@app.post("/api/v1/tasks")
def create_task(body: CreateTaskBody, authorization: Optional[str] = Header(default=None)):
    verify_auth(authorization)
    if body.idempotency_key in IDEMPOTENCY_INDEX:
        return TASKS_BY_ID[IDEMPOTENCY_INDEX[body.idempotency_key]]
    if body.agent_id not in AGENTS:
        raise HTTPException(status_code=400, detail="Geçersiz ajan kimliği")
    task_id = str(uuid.uuid4())
    record = TaskRecord(
        task_id=task_id,
        idempotency_key=body.idempotency_key,
        title=body.title,
        prompt=body.prompt,
        agent_id=body.agent_id,
        priority=body.priority,
        status="QUEUED",
        result_summary="Windows koordinatör kuyruğuna alındı."
    )
    TASKS_BY_ID[task_id] = record
    IDEMPOTENCY_INDEX[body.idempotency_key] = task_id
    return record

@app.delete("/api/v1/tasks/{task_id}")
def cancel_task(task_id: str, authorization: Optional[str] = Header(default=None)):
    verify_auth(authorization)
    if task_id in TASKS_BY_ID:
        TASKS_BY_ID[task_id].status = "CANCELLED"
    return {"cancelled": True}

@app.post("/api/v1/discovery/scan")
async def scan_tools(authorization: Optional[str] = Header(default=None)):
    verify_auth(authorization)
    tools = [
        {"name": "Claude Code", "available": shutil.which("claude") is not None, "status": "READY" if shutil.which("claude") else "NOT_IN_PATH"},
        {"name": "Codex", "available": shutil.which("codex") is not None, "status": "READY" if shutil.which("codex") else "NOT_IN_PATH"},
        {"name": "OpenAI", "available": bool(os.getenv("OPENAI_API_KEY")), "status": "KEY_SET" if os.getenv("OPENAI_API_KEY") else "NO_API_KEY"},
    ]
    ollama_models = []
    try:
        async with httpx.AsyncClient(timeout=2.5) as client:
            r = await client.get("http://127.0.0.1:11434/api/tags")
            if r.status_code == 200:
                for m in r.json().get("models", []):
                    size_gb = round(m.get("size", 0) / (1024**3), 2)
                    ollama_models.append({
                        "name": m.get("name", "unknown"),
                        "size": f"{size_gb} GB",
                        "available": True,
                        "status": "ONLINE"
                    })
    except Exception:
        ollama_models.append({"name": "Ollama Servisi", "size": "-", "available": False, "status": "OFFLINE"})
    return {"tools": tools, "ollama_models": ollama_models}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8787)
