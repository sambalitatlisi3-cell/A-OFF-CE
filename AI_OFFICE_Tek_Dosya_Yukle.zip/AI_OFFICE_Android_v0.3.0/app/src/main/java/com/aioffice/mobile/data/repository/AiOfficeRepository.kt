package com.aioffice.mobile.data.repository

import com.aioffice.mobile.data.local.ConnectionSettings
import com.aioffice.mobile.data.local.SettingsStore
import com.aioffice.mobile.data.local.TaskDao
import com.aioffice.mobile.data.local.TaskEntity
import com.aioffice.mobile.data.remote.AgentActivationRequest
import com.aioffice.mobile.data.remote.CoordinatorApiService
import com.aioffice.mobile.data.remote.CoordinatorClientFactory
import com.aioffice.mobile.data.remote.CreateTaskRequest
import com.aioffice.mobile.domain.model.*
import kotlinx.coroutines.flow.*
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.UUID

class AiOfficeRepository(
    private val taskDao: TaskDao,
    val settingsStore: SettingsStore,
    private val notificationHelper: com.aioffice.mobile.notification.NotificationHelper
) {
    private val _connectionState = MutableStateFlow(ConnectionState.OFFLINE)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _statusDetail = MutableStateFlow("PC bağlantısı kurulmadı (Yerel kuyruk modu aktif)")
    val statusDetail: StateFlow<String> = _statusDetail.asStateFlow()

    private val _agents = MutableStateFlow(
        AgentType.entries.map { AgentState(type = it) }
    )
    val agents: StateFlow<List<AgentState>> = _agents.asStateFlow()

    private val _discoveredTools = MutableStateFlow<List<DiscoveredTool>>(emptyList())
    val discoveredTools: StateFlow<List<DiscoveredTool>> = _discoveredTools.asStateFlow()

    private val _activities = MutableStateFlow<List<ActivityLog>>(
        listOf(
            ActivityLog(
                id = UUID.randomUUID().toString(),
                title = "AI OFFICE Mobil v0.3.0 Hazır",
                detail = "Çevrimdışı görev kuyruğu ve 3 ajanlı mimari başlatıldı.",
                timestamp = System.currentTimeMillis()
            )
        )
    )
    val activities: StateFlow<List<ActivityLog>> = _activities.asStateFlow()

    val tasksFlow: Flow<List<TaskEntity>> = taskDao.observeAllTasks()

    private suspend fun buildApi(settings: ConnectionSettings): CoordinatorApiService {
        return CoordinatorClientFactory.create(settings.buildBaseUrl(), settings.apiToken)
    }

    private fun addActivity(title: String, detail: String, isError: Boolean = false) {
        val entry = ActivityLog(
            id = UUID.randomUUID().toString(),
            title = title,
            detail = detail,
            timestamp = System.currentTimeMillis(),
            isError = isError
        )
        _activities.update { (listOf(entry) + it).take(40) }
    }

    private fun humanizeError(t: Throwable): String = when (t) {
        is SocketTimeoutException -> "Zaman aşımı: Windows koordinatörü yanıt vermedi."
        is ConnectException -> "Bağlantı reddedildi: PC kapalı veya AI OFFICE servisi çalışmıyor."
        is UnknownHostException -> "Sunucu bulunamadı: IP adresini kontrol edin."
        else -> "Bağlantı/API hatası: ${t.localizedMessage ?: "Bilinmeyen hata"}"
    }

    suspend fun testAndSyncConnection() {
        val settings = settingsStore.settingsFlow.first()
        val previousState = _connectionState.value
        _connectionState.value = ConnectionState.CONNECTING
        _statusDetail.value = "${settings.buildBaseUrl()} adresine bağlanılıyor..."

        try {
            val api = buildApi(settings)
            val status = api.getStatus()
            _connectionState.value = ConnectionState.ONLINE
            _statusDetail.value = "Windows Koordinatör ONLINE (Sürüm: ${status.version})"

            if (previousState != ConnectionState.ONLINE) {
                addActivity("PC Bağlandı", _statusDetail.value)
                notificationHelper.notifyEvent(
                    "PC Bağlantısı Kuruldu",
                    "Windows AI OFFICE koordinatörü çevrimiçi.",
                    settings.notificationsEnabled
                )
            }

            refreshAgents(api)
            if (settings.autoSync) {
                syncPendingTasks(api, settings)
            }
            refreshRemoteTasks(api, settings)
        } catch (e: Exception) {
            val msg = humanizeError(e)
            _connectionState.value = if (e is ConnectException) ConnectionState.OFFLINE else ConnectionState.ERROR
            _statusDetail.value = msg
            if (previousState == ConnectionState.ONLINE) {
                notificationHelper.notifyEvent(
                    "PC Bağlantısı Kesildi",
                    msg,
                    settings.notificationsEnabled
                )
            }
            addActivity("Bağlantı Hatası", msg, isError = true)
        }
    }

    private suspend fun refreshAgents(api: CoordinatorApiService) {
        val remoteAgents = api.getAgents()
        _agents.value = AgentType.entries.map { type ->
            val match = remoteAgents.firstOrNull { it.id.equals(type.id, ignoreCase = true) }
            if (match != null) {
                AgentState(
                    type = type,
                    isEnabled = match.enabled,
                    isConnected = match.connected,
                    lastAction = match.lastAction ?: "Hazır",
                    runningTaskTitle = match.runningTask
                )
            } else {
                AgentState(
                    type = type,
                    isEnabled = false,
                    isConnected = false,
                    lastAction = "Koordinatörde bildirilmedi"
                )
            }
        }
    }

    suspend fun toggleAgentWithUserConfirmation(agentType: AgentType, targetEnabled: Boolean) {
        val settings = settingsStore.settingsFlow.first()
        if (_connectionState.value != ConnectionState.ONLINE) {
            addActivity(
                "${agentType.displayName} Değiştirilemedi",
                "PC çevrimdışı. Ajan durumu yalnızca PC çevrimiçiyken değiştirilebilir.",
                isError = true
            )
            return
        }
        try {
            val api = buildApi(settings)
            val updated = api.setAgentActivation(
                agentId = agentType.id,
                body = AgentActivationRequest(enabled = targetEnabled, userConfirmed = true)
            )
            _agents.update { list ->
                list.map {
                    if (it.type == agentType) {
                        it.copy(
                            isEnabled = updated.enabled,
                            isConnected = updated.connected,
                            lastAction = if (updated.enabled) "Kullanıcı onayıyla etkinleştirildi" else "Devre dışı bırakıldı"
                        )
                    } else it
                }
            }
            addActivity(
                "${agentType.displayName} ${if (targetEnabled) "Etkinleştirildi" else "Durduruldu"}",
                "Kullanıcı onayı ile koordinatöre iletildi."
            )
        } catch (e: Exception) {
            addActivity("${agentType.displayName} Hatası", humanizeError(e), isError = true)
        }
    }

    suspend fun createAndQueueTask(title: String, prompt: String, agent: AgentType, priority: TaskPriority) {
        val settings = settingsStore.settingsFlow.first()
        val initialStatus = if (_connectionState.value == ConnectionState.ONLINE) TaskStatus.QUEUED else TaskStatus.WAITING
        val task = TaskEntity(
            title = title.trim(),
            prompt = prompt.trim(),
            agentId = agent.id,
            priorityLevel = priority.level,
            status = initialStatus.name,
            isSynced = false
        )
        taskDao.insertTask(task)
        addActivity(
            "Görev Oluşturuldu (${initialStatus.label})",
            "${agent.displayName} -> ${task.title}"
        )

        if (_connectionState.value == ConnectionState.ONLINE) {
            try {
                val api = buildApi(settings)
                syncSingleTask(api, task)
            } catch (e: Exception) {
                addActivity("Gönderim Beklemeye Alındı", humanizeError(e), isError = true)
            }
        }
    }

    private suspend fun syncPendingTasks(api: CoordinatorApiService, settings: ConnectionSettings) {
        val pending = taskDao.getPendingUnsyncedTasks()
        for (task in pending) {
            syncSingleTask(api, task)
        }
        if (pending.isNotEmpty()) {
            addActivity("Kuyruk Senkronize Edildi", "${pending.size} bekleyen görev PC'ye aktarıldı.")
        }
    }

    private suspend fun syncSingleTask(api: CoordinatorApiService, task: TaskEntity) {
        if (task.isSynced && task.remoteTaskId != null) return
        val remote = api.submitTask(
            CreateTaskRequest(
                idempotencyKey = task.idempotencyKey,
                title = task.title,
                prompt = task.prompt,
                agentId = task.agentId,
                priority = task.priorityLevel
            )
        )
        val mappedStatus = TaskStatus.entries.firstOrNull { it.name.equals(remote.status, true) } ?: TaskStatus.QUEUED
        taskDao.updateTask(
            task.copy(
                remoteTaskId = remote.taskId,
                status = mappedStatus.name,
                isSynced = true,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    private suspend fun refreshRemoteTasks(api: CoordinatorApiService, settings: ConnectionSettings) {
        val remoteList = api.getTasks()
        for (remote in remoteList) {
            val key = remote.idempotencyKey ?: continue
            val local = taskDao.getTaskByIdempotencyKey(key) ?: continue
            val newStatus = TaskStatus.entries.firstOrNull { it.name.equals(remote.status, true) } ?: continue
            if (local.status != newStatus.name) {
                taskDao.updateTask(
                    local.copy(
                        remoteTaskId = remote.taskId,
                        status = newStatus.name,
                        errorMessage = remote.errorMessage,
                        resultSummary = remote.resultSummary,
                        updatedAt = System.currentTimeMillis()
                    )
                )
                if (newStatus in listOf(TaskStatus.RUNNING, TaskStatus.COMPLETED, TaskStatus.FAILED)) {
                    notificationHelper.notifyEvent(
                        "Görev ${newStatus.label}: ${local.title}",
                        remote.resultSummary ?: remote.errorMessage ?: "Durum güncellendi.",
                        settings.notificationsEnabled
                    )
                }
            }
        }
    }

    suspend fun cancelTask(task: TaskEntity) {
        val settings = settingsStore.settingsFlow.first()
        if (task.remoteTaskId != null && _connectionState.value == ConnectionState.ONLINE) {
            try {
                val api = buildApi(settings)
                api.cancelTask(task.remoteTaskId)
            } catch (_: Exception) {
            }
        }
        taskDao.updateTask(
            task.copy(
                status = TaskStatus.CANCELLED.name,
                updatedAt = System.currentTimeMillis()
            )
        )
        addActivity("Görev İptal Edildi", task.title)
    }

    suspend fun discoverToolsAndModels() {
        val settings = settingsStore.settingsFlow.first()
        if (_connectionState.value != ConnectionState.ONLINE) {
            _discoveredTools.value = listOf(
                DiscoveredTool("Claude Code", "Ajan CLI", "-", false, "PC OFFLINE", isDemo = false),
                DiscoveredTool("Codex", "Ajan CLI", "-", false, "PC OFFLINE", isDemo = false),
                DiscoveredTool("OpenAI", "API / Ajan", "-", false, "PC OFFLINE", isDemo = false),
                DiscoveredTool("Ollama", "Yerel LLM Sunucusu", "-", false, "PC OFFLINE (Bağlantı gerekli)", isDemo = false)
            )
            addActivity("Keşif Yapılamadı", "PC çevrimdışı olduğu için araç ve Ollama modelleri sorgulanamadı.", isError = true)
            return
        }
        try {
            val api = buildApi(settings)
            val response = api.scanToolsAndModels()
            val mapped = mutableListOf<DiscoveredTool>()
            response.tools.forEach {
                mapped.add(
                    DiscoveredTool(
                        name = it.name,
                        category = "AI Araç",
                        sizeLabel = "-",
                        isAvailable = it.available,
                        connectionStatus = it.status
                    )
                )
            }
            response.ollamaModels.forEach {
                mapped.add(
                    DiscoveredTool(
                        name = it.name,
                        category = "Ollama Model",
                        sizeLabel = it.size,
                        isAvailable = it.available,
                        connectionStatus = it.status
                    )
                )
            }
            _discoveredTools.value = mapped
            addActivity("Araç & Model Keşfi Tamamlandı", "${mapped.size} öğe listelendi (Ajanlar tetiklenmedi).")
        } catch (e: Exception) {
            addActivity("Keşif Hatası", humanizeError(e), isError = true)
        }
    }
}
