package com.aioffice.mobile.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.aioffice.mobile.data.local.ConnectionSettings
import com.aioffice.mobile.data.local.TaskEntity
import com.aioffice.mobile.data.repository.AiOfficeRepository
import com.aioffice.mobile.domain.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(private val repository: AiOfficeRepository) : ViewModel() {
    val connectionState: StateFlow<ConnectionState> = repository.connectionState
    val statusDetail: StateFlow<String> = repository.statusDetail
    val agents: StateFlow<List<AgentState>> = repository.agents
    val discoveredTools: StateFlow<List<DiscoveredTool>> = repository.discoveredTools
    val activities: StateFlow<List<ActivityLog>> = repository.activities

    val tasks: StateFlow<List<TaskEntity>> = repository.tasksFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<ConnectionSettings> = repository.settingsStore.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ConnectionSettings())

    init {
        refreshConnection()
    }

    fun refreshConnection() {
        viewModelScope.launch {
            repository.testAndSyncConnection()
        }
    }

    fun createTask(title: String, prompt: String, agent: AgentType, priority: TaskPriority) {
        if (title.isBlank() || prompt.isBlank()) return
        viewModelScope.launch {
            repository.createAndQueueTask(title, prompt, agent, priority)
        }
    }

    fun cancelTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.cancelTask(task)
        }
    }

    fun toggleAgent(agentType: AgentType, enable: Boolean) {
        viewModelScope.launch {
            repository.toggleAgentWithUserConfirmation(agentType, enable)
        }
    }

    fun scanTools() {
        viewModelScope.launch {
            repository.discoverToolsAndModels()
        }
    }

    fun saveSettings(
        host: String,
        port: Int,
        useHttps: Boolean,
        autoSync: Boolean,
        notificationsEnabled: Boolean,
        amoledPureBlack: Boolean,
        apiToken: String,
        testImmediately: Boolean
    ) {
        viewModelScope.launch {
            repository.settingsStore.saveSettings(
                host = host,
                port = port,
                useHttps = useHttps,
                autoSync = autoSync,
                notificationsEnabled = notificationsEnabled,
                amoledPureBlack = amoledPureBlack,
                apiToken = apiToken
            )
            if (testImmediately) {
                repository.testAndSyncConnection()
            }
        }
    }

    class Factory(private val repository: AiOfficeRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = MainViewModel(repository) as T
    }
}
