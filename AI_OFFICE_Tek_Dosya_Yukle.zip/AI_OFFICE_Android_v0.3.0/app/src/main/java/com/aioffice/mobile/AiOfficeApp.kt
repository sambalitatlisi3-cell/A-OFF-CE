package com.aioffice.mobile

import android.app.Application
import com.aioffice.mobile.data.local.AiOfficeDatabase
import com.aioffice.mobile.data.local.SettingsStore
import com.aioffice.mobile.data.repository.AiOfficeRepository
import com.aioffice.mobile.notification.NotificationHelper

class AiOfficeApp : Application() {
    lateinit var repository: AiOfficeRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val database = AiOfficeDatabase.getInstance(this)
        val settingsStore = SettingsStore(this)
        val notificationHelper = NotificationHelper(this)
        repository = AiOfficeRepository(
            taskDao = database.taskDao(),
            settingsStore = settingsStore,
            notificationHelper = notificationHelper
        )
    }
}
