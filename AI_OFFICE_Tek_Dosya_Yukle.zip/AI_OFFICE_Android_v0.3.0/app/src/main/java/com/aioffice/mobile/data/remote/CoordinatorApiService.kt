package com.aioffice.mobile.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

@Serializable
data class SystemStatusDto(
    val status: String = "ONLINE",
    val version: String = "unknown",
    @SerialName("active_agents") val activeAgents: Int = 0,
    @SerialName("queued_tasks") val queuedTasks: Int = 0
)

@Serializable
data class AgentDto(
    val id: String,
    val name: String,
    val enabled: Boolean = false,
    val connected: Boolean = false,
    @SerialName("last_action") val lastAction: String? = null,
    @SerialName("running_task") val runningTask: String? = null
)

@Serializable
data class AgentActivationRequest(
    val enabled: Boolean,
    @SerialName("user_confirmed") val userConfirmed: Boolean = true
)

@Serializable
data class CreateTaskRequest(
    @SerialName("idempotency_key") val idempotencyKey: String,
    val title: String,
    val prompt: String,
    @SerialName("agent_id") val agentId: String,
    val priority: Int
)

@Serializable
data class RemoteTaskDto(
    @SerialName("task_id") val taskId: String,
    @SerialName("idempotency_key") val idempotencyKey: String? = null,
    val title: String,
    val prompt: String = "",
    @SerialName("agent_id") val agentId: String,
    val priority: Int = 2,
    val status: String,
    @SerialName("error_message") val errorMessage: String? = null,
    @SerialName("result_summary") val resultSummary: String? = null
)

@Serializable
data class DiscoveryResponseDto(
    val tools: List<DiscoveredToolDto> = emptyList(),
    @SerialName("ollama_models") val ollamaModels: List<OllamaModelDto> = emptyList()
)

@Serializable
data class DiscoveredToolDto(
    val name: String,
    val available: Boolean = false,
    val status: String = "UNKNOWN"
)

@Serializable
data class OllamaModelDto(
    val name: String,
    val size: String = "-",
    val available: Boolean = true,
    val status: String = "READY"
)

interface CoordinatorApiService {
    @GET("api/v1/status")
    suspend fun getStatus(): SystemStatusDto

    @GET("api/v1/agents")
    suspend fun getAgents(): List<AgentDto>

    @POST("api/v1/agents/{agentId}/activation")
    suspend fun setAgentActivation(
        @Path("agentId") agentId: String,
        @Body body: AgentActivationRequest
    ): AgentDto

    @GET("api/v1/tasks")
    suspend fun getTasks(): List<RemoteTaskDto>

    @POST("api/v1/tasks")
    suspend fun submitTask(@Body body: CreateTaskRequest): RemoteTaskDto

    @DELETE("api/v1/tasks/{taskId}")
    suspend fun cancelTask(@Path("taskId") taskId: String)

    @POST("api/v1/discovery/scan")
    suspend fun scanToolsAndModels(): DiscoveryResponseDto
}

object CoordinatorClientFactory {
    private val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
    }

    fun create(baseUrl: String, apiToken: String): CoordinatorApiService {
        val logger = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
            redactHeader("Authorization")
            redactHeader("X-API-Key")
        }

        val client = OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .addInterceptor { chain ->
                val reqBuilder = chain.request().newBuilder()
                    .header("Accept", "application/json")
                if (apiToken.isNotBlank()) {
                    reqBuilder.header("Authorization", "Bearer $apiToken")
                }
                chain.proceed(reqBuilder.build())
            }
            .addInterceptor(logger)
            .build()

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(CoordinatorApiService::class.java)
    }
}
