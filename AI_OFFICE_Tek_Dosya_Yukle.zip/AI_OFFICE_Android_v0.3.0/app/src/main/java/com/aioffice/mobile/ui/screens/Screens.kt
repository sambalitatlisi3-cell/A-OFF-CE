package com.aioffice.mobile.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.aioffice.mobile.data.local.ConnectionSettings
import com.aioffice.mobile.data.local.TaskEntity
import com.aioffice.mobile.domain.model.*
import com.aioffice.mobile.ui.MainViewModel
import com.aioffice.mobile.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun StatusPill(state: ConnectionState) {
    val color = when (state) {
        ConnectionState.ONLINE -> StatusSuccess
        ConnectionState.OFFLINE -> TextSecondary
        ConnectionState.CONNECTING -> StatusWarning
        ConnectionState.ERROR -> StatusError
    }
    Surface(
        color = color.copy(alpha = 0.16f),
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Text(state.label, color = color, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun DashboardScreen(viewModel: MainViewModel) {
    val connectionState by viewModel.connectionState.collectAsState()
    val statusDetail by viewModel.statusDetail.collectAsState()
    val agents by viewModel.agents.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val activities by viewModel.activities.collectAsState()

    val activeAgentCount = agents.count { it.isEnabled }
    val pendingCount = tasks.count { it.toTaskStatus() in listOf(TaskStatus.WAITING, TaskStatus.QUEUED, TaskStatus.RUNNING) }
    val completedCount = tasks.count { it.toTaskStatus() == TaskStatus.COMPLETED }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        color = AccentPurple.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AccentPurple)
                    ) {
                        Icon(
                            Icons.Default.Hub,
                            contentDescription = "AI OFFICE",
                            tint = AccentPurple,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Column {
                        Text("AI OFFICE", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("Mobil Kontrol Merkezi • v0.3.0", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    }
                }
                StatusPill(connectionState)
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Sistem Durumu", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        FilledTonalButton(onClick = { viewModel.refreshConnection() }) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Senkronize Et")
                        }
                    }
                    Text(statusDetail, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Aktif Ajan", "$activeAgentCount / 3", AccentPurple, Modifier.weight(1f))
                MetricCard("Bekleyen", "$pendingCount", StatusWarning, Modifier.weight(1f))
                MetricCard("Tamamlanan", "$completedCount", StatusSuccess, Modifier.weight(1f))
            }
        }

        item {
            Text("Son Aktiviteler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }

        items(activities) { log ->
            val fmt = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCardSecondary),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (log.isError) StatusError.copy(alpha = 0.5f) else BorderSubtle)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            log.title,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (log.isError) StatusError else TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(fmt.format(Date(log.timestamp)), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Text(log.detail, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = BgCard),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = accent)
            Text(label, style = MaterialTheme.typography.labelMedium, color = TextSecondary)
        }
    }
}

@Composable
fun TasksScreen(viewModel: MainViewModel) {
    val tasks by viewModel.tasks.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()

    var title by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var selectedAgent by remember { mutableStateOf(AgentType.CLAUDE_CODE) }
    var selectedPriority by remember { mutableStateOf(TaskPriority.NORMAL) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Görev Kuyruğu & Oluşturma", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Görev Başlığı") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        label = { Text("Görev Promptu") },
                        minLines = 4,
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Hedef Ajan", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AgentType.entries.forEach { agent ->
                            FilterChip(
                                selected = selectedAgent == agent,
                                onClick = { selectedAgent = agent },
                                label = { Text(agent.displayName) }
                            )
                        }
                    }

                    Text("Öncelik", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TaskPriority.entries.forEach { prio ->
                            FilterChip(
                                selected = selectedPriority == prio,
                                onClick = { selectedPriority = prio },
                                label = { Text(prio.label) }
                            )
                        }
                    }

                    Button(
                        onClick = {
                            viewModel.createTask(title, prompt, selectedAgent, selectedPriority)
                            title = ""
                            prompt = ""
                        },
                        enabled = title.isNotBlank() && prompt.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = AccentPurple)
                    ) {
                        Icon(Icons.Default.AddTask, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (connectionState == ConnectionState.ONLINE)
                                "Kuyruğa Ekle ve Gönder"
                            else
                                "Çevrimdışı Kuyruğa Kaydet (WAITING)"
                        )
                    }
                }
            }
        }

        item {
            Text("Görev Geçmişi (${tasks.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }

        items(tasks, key = { it.localId }) { task ->
            val st = task.toTaskStatus()
            val statusColor = when (st) {
                TaskStatus.COMPLETED -> StatusSuccess
                TaskStatus.FAILED, TaskStatus.CANCELLED -> StatusError
                TaskStatus.RUNNING, TaskStatus.QUEUED -> AccentPurple
                TaskStatus.WAITING -> StatusWarning
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCardSecondary),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(task.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(st.label, color = statusColor, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        "${task.toAgentType().displayName} • Öncelik: ${task.toPriority().label}",
                        style = MaterialTheme.typography.labelSmall,
                        color = AccentPurple
                    )
                    Text(task.prompt, style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 3)
                    if (!st.isTerminal) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { viewModel.cancelTask(task) }) {
                                Text("Görevi İptal Et", color = StatusError)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AgentsScreen(viewModel: MainViewModel) {
    val agents by viewModel.agents.collectAsState()
    val tools by viewModel.discoveredTools.collectAsState()
    var pendingToggle by remember { mutableStateOf<Pair<AgentType, Boolean>?>(null) }

    pendingToggle?.let { (agent, targetState) ->
        AlertDialog(
            onDismissRequest = { pendingToggle = null },
            title = { Text("Kullanıcı Onayı Gerekli") },
            text = {
                Text(
                    "${agent.displayName} ajanını ${if (targetState) "ETKİNLEŞTİRMEK" else "DEVRE DIŞI BIRAKMAK"} istediğinize emin misiniz?"
                )
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.toggleAgent(agent, targetState)
                    pendingToggle = null
                }) { Text("Onayla") }
            },
            dismissButton = {
                TextButton(onClick = { pendingToggle = null }) { Text("Vazgeç") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Üç Ajanlı Kontrol Merkezi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Ajanlar kullanıcı onayı olmadan etkinleştirilmez.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }

        items(agents) { agentState ->
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, if (agentState.isEnabled) AccentPurple else BorderSubtle)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(agentState.type.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = AccentPurple)
                            Text(agentState.type.roleSummary, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                        }
                        Switch(
                            checked = agentState.isEnabled,
                            onCheckedChange = { desired -> pendingToggle = agentState.type to desired }
                        )
                    }
                    Text(
                        "Durum: ${if (agentState.isEnabled) "AKTİF" else "PASİF"} • Bağlantı: ${if (agentState.isConnected) "BAĞLI" else "BAĞLI DEĞİL"}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (agentState.isConnected) StatusSuccess else TextSecondary
                    )
                    Text("Son İşlem: ${agentState.lastAction}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Text("Çalışan Görev: ${agentState.runningTaskTitle ?: "Yok"}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Araç & Ollama Model Keşfi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                FilledTonalButton(onClick = { viewModel.scanTools() }) {
                    Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Keşfet")
                }
            }
        }

        items(tools) { tool ->
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCardSecondary),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(tool.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text("${tool.category} • Boyut: ${tool.sizeLabel}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Text(
                        tool.connectionStatus,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (tool.isAvailable) StatusSuccess else StatusWarning
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val current by viewModel.settings.collectAsState()

    var host by remember(current) { mutableStateOf(current.host) }
    var port by remember(current) { mutableStateOf(current.port.toString()) }
    var token by remember(current) { mutableStateOf(current.apiToken) }
    var useHttps by remember(current) { mutableStateOf(current.useHttps) }
    var autoSync by remember(current) { mutableStateOf(current.autoSync) }
    var notifications by remember(current) { mutableStateOf(current.notificationsEnabled) }
    var amoled by remember(current) { mutableStateOf(current.amoledPureBlack) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Bağlantı & Sistem Ayarları", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCard),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = host,
                        onValueChange = { host = it },
                        label = { Text("Windows PC IP / Sunucu Adresi") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = port,
                        onValueChange = { port = it.filter(Char::isDigit) },
                        label = { Text("Port (Örn: 8787)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = token,
                        onValueChange = { token = it },
                        label = { Text("API Token (AES-256 Şifreli Saklanır)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    SettingSwitchRow("HTTPS Kullan", useHttps) { useHttps = it }
                    SettingSwitchRow("PC Çevrimiçi Olunca Otomatik Senkronize Et", autoSync) { autoSync = it }
                    SettingSwitchRow("Görev & Bağlantı Bildirimleri", notifications) { notifications = it }
                    SettingSwitchRow("AMOLED Saf Siyah Tema", amoled) { amoled = it }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = {
                                viewModel.saveSettings(
                                    host = host,
                                    port = port.toIntOrNull() ?: 8787,
                                    useHttps = useHttps,
                                    autoSync = autoSync,
                                    notificationsEnabled = notifications,
                                    amoledPureBlack = amoled,
                                    apiToken = token,
                                    testImmediately = false
                                )
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Kaydet") }

                        Button(
                            onClick = {
                                viewModel.saveSettings(
                                    host = host,
                                    port = port.toIntOrNull() ?: 8787,
                                    useHttps = useHttps,
                                    autoSync = autoSync,
                                    notificationsEnabled = notifications,
                                    amoledPureBlack = amoled,
                                    apiToken = token,
                                    testImmediately = true
                                )
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentPurple)
                        ) { Text("Kaydet & Test Et") }
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgCardSecondary),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Hakkında", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text("AI OFFICE Android v0.3.0 (com.aioffice.mobile)", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Text("Windows AI OFFICE koordinasyon sistemi için mobil kontrol merkezi.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
