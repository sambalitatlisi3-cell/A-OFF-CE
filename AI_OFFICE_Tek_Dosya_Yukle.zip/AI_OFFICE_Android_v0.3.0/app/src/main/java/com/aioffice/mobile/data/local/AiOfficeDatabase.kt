package com.aioffice.mobile.data.local

import android.content.Context
import androidx.room.*
import com.aioffice.mobile.domain.model.AgentType
import com.aioffice.mobile.domain.model.TaskPriority
import com.aioffice.mobile.domain.model.TaskStatus
import kotlinx.coroutines.flow.Flow
import java.util.UUID

@Entity(
    tableName = "tasks",
    indices = [Index(value = ["idempotencyKey"], unique = true)]
)
data class TaskEntity(
    @PrimaryKey val localId: String = UUID.randomUUID().toString(),
    val idempotencyKey: String = UUID.randomUUID().toString(),
    val remoteTaskId: String? = null,
    val title: String,
    val prompt: String,
    val agentId: String,
    val priorityLevel: Int,
    val status: String,
    val errorMessage: String? = null,
    val resultSummary: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false
) {
    fun toAgentType(): AgentType =
        AgentType.entries.firstOrNull { it.id == agentId } ?: AgentType.CLAUDE_CODE

    fun toTaskStatus(): TaskStatus =
        TaskStatus.entries.firstOrNull { it.name == status } ?: TaskStatus.WAITING

    fun toPriority(): TaskPriority =
        TaskPriority.entries.firstOrNull { it.level == priorityLevel } ?: TaskPriority.NORMAL
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY priorityLevel DESC, createdAt DESC")
    fun observeAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE status IN ('WAITING', 'QUEUED') AND isSynced = 0 ORDER BY priorityLevel DESC, createdAt ASC")
    suspend fun getPendingUnsyncedTasks(): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE localId = :localId LIMIT 1")
    suspend fun getTaskById(localId: String): TaskEntity?

    @Query("SELECT * FROM tasks WHERE idempotencyKey = :key LIMIT 1")
    suspend fun getTaskByIdempotencyKey(key: String): TaskEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTask(task: TaskEntity): Long

    @Update
    suspend fun updateTask(task: TaskEntity)
}

@Database(entities = [TaskEntity::class], version = 1, exportSchema = false)
abstract class AiOfficeDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile
        private var INSTANCE: AiOfficeDatabase? = null

        fun getInstance(context: Context): AiOfficeDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AiOfficeDatabase::class.java,
                    "ai_office_v030.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
