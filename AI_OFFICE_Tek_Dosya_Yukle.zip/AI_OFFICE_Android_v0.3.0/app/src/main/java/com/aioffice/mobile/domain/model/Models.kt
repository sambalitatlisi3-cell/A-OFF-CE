package com.aioffice.mobile.domain.model

enum class ConnectionState(val label: String) {
    ONLINE("ONLINE"),
    OFFLINE("OFFLINE"),
    CONNECTING("CONNECTING"),
    ERROR("ERROR")
}

enum class AgentType(
    val id: String,
    val displayName: String,
    val roleSummary: String,
    val capabilities: List<String>
) {
    CLAUDE_CODE(
        id = "claude_code",
        displayName = "CLAUDE CODE",
        roleSummary = "Luau & Roblox Mekanik Geliştirme",
        capabilities = listOf(
            "Luau ve Roblox mekanik geliştirme",
            "Oyun sistemleri oluşturma",
            "Script yazma",
            "Mevcut mekanikleri geliştirme"
        )
    ),
    CODEX(
        id = "codex",
        displayName = "CODEX",
        roleSummary = "Profesyonel UI, Modelleme & Büyük Proje İş Akışları",
        capabilities = listOf(
            "Profesyonel UI geliştirme",
            "Harita ve modelleme iş akışları",
            "Proje dosyaları oluşturma",
            "Büyük çaplı proje geliştirme"
        )
    ),
    OPENAI(
        id = "openai",
        displayName = "OPENAI",
        roleSummary = "Hata Tespiti, Kod Analizi & Kalite Kontrol",
        capabilities = listOf(
            "Hata tespiti",
            "Kod analizi",
            "Hata düzeltme",
            "Kalite kontrol & diğer ajanların ürettiği işleri inceleme"
        )
    )
}

enum class TaskStatus(val label: String, val isTerminal: Boolean) {
    WAITING("WAITING", false),
    QUEUED("QUEUED", false),
    RUNNING("RUNNING", false),
    COMPLETED("COMPLETED", true),
    FAILED("FAILED", true),
    CANCELLED("CANCELLED", true)
}

enum class TaskPriority(val label: String, val level: Int) {
    LOW("Düşük", 1),
    NORMAL("Normal", 2),
    HIGH("Yüksek", 3),
    CRITICAL("Kritik", 4)
}

data class AgentState(
    val type: AgentType,
    val isEnabled: Boolean = false,
    val isConnected: Boolean = false,
    val lastAction: String = "Henüz işlem yok (Manuel onay bekleniyor)",
    val runningTaskTitle: String? = null
)

data class DiscoveredTool(
    val name: String,
    val category: String,
    val sizeLabel: String,
    val isAvailable: Boolean,
    val connectionStatus: String,
    val isDemo: Boolean = false
)

data class ActivityLog(
    val id: String,
    val title: String,
    val detail: String,
    val timestamp: Long,
    val isError: Boolean = false
)
