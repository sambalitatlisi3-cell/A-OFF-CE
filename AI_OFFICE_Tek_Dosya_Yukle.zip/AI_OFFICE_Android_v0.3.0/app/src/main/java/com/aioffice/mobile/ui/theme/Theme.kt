package com.aioffice.mobile.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BgPrimary = Color(0xFF090B10)
val BgCard = Color(0xFF131722)
val BgCardSecondary = Color(0xFF1A2030)
val AccentPurple = Color(0xFF7C6CFF)
val StatusSuccess = Color(0xFF48D6A0)
val StatusWarning = Color(0xFFFFB454)
val StatusError = Color(0xFFFF5D6C)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF929BAD)
val BorderSubtle = Color(0xFF252D40)

@Composable
fun AiOfficeTheme(
    amoledBlack: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = darkColorScheme(
        primary = AccentPurple,
        onPrimary = TextPrimary,
        background = if (amoledBlack) Color(0xFF000000) else BgPrimary,
        surface = BgCard,
        surfaceVariant = BgCardSecondary,
        onBackground = TextPrimary,
        onSurface = TextPrimary,
        onSurfaceVariant = TextSecondary,
        error = StatusError,
        outline = BorderSubtle
    )

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
