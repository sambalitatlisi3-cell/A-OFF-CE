package com.aioffice.mobile.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "ai_office_settings")

data class ConnectionSettings(
    val host: String = "192.168.1.100",
    val port: Int = 8787,
    val useHttps: Boolean = false,
    val autoSync: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val amoledPureBlack: Boolean = false,
    val apiToken: String = ""
) {
    fun buildBaseUrl(): String {
        val scheme = if (useHttps) "https" else "http"
        val cleanHost = host.trim().ifEmpty { "127.0.0.1" }
        return "$scheme://$cleanHost:$port/"
    }
}

class SettingsStore(context: Context) {
    private val appContext = context.applicationContext

    private object Keys {
        val HOST = stringPreferencesKey("pc_host")
        val PORT = intPreferencesKey("pc_port")
        val USE_HTTPS = booleanPreferencesKey("use_https")
        val AUTO_SYNC = booleanPreferencesKey("auto_sync")
        val NOTIFICATIONS = booleanPreferencesKey("notifications_enabled")
        val AMOLED_BLACK = booleanPreferencesKey("amoled_black")
    }

    private val encryptedPrefs by lazy {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            appContext,
            "ai_office_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    val settingsFlow: Flow<ConnectionSettings> = appContext.dataStore.data.map { prefs ->
        ConnectionSettings(
            host = prefs[Keys.HOST] ?: "192.168.1.100",
            port = prefs[Keys.PORT] ?: 8787,
            useHttps = prefs[Keys.USE_HTTPS] ?: false,
            autoSync = prefs[Keys.AUTO_SYNC] ?: true,
            notificationsEnabled = prefs[Keys.NOTIFICATIONS] ?: true,
            amoledPureBlack = prefs[Keys.AMOLED_BLACK] ?: false,
            apiToken = getApiToken()
        )
    }

    fun getApiToken(): String = encryptedPrefs.getString("api_token", "") ?: ""

    suspend fun saveSettings(
        host: String,
        port: Int,
        useHttps: Boolean,
        autoSync: Boolean,
        notificationsEnabled: Boolean,
        amoledPureBlack: Boolean,
        apiToken: String
    ) {
        encryptedPrefs.edit().putString("api_token", apiToken.trim()).apply()
        appContext.dataStore.edit { prefs ->
            prefs[Keys.HOST] = host.trim()
            prefs[Keys.PORT] = port.coerceIn(1, 65535)
            prefs[Keys.USE_HTTPS] = useHttps
            prefs[Keys.AUTO_SYNC] = autoSync
            prefs[Keys.NOTIFICATIONS] = notificationsEnabled
            prefs[Keys.AMOLED_BLACK] = amoledPureBlack
        }
    }
}
