package com.aioffice.mobile

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aioffice.mobile.ui.MainViewModel
import com.aioffice.mobile.ui.screens.*
import com.aioffice.mobile.ui.theme.AiOfficeTheme
import com.aioffice.mobile.ui.theme.BgCard

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as AiOfficeApp

        setContent {
            val vm: MainViewModel = viewModel(factory = MainViewModel.Factory(app.repository))
            val settings by vm.settings.collectAsState()
            var selectedTab by remember { mutableIntStateOf(0) }

            val permissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) {}

            LaunchedEffect(Unit) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }

            AiOfficeTheme(amoledBlack = settings.amoledPureBlack) {
                Scaffold(
                    bottomBar = {
                        NavigationBar(containerColor = BgCard) {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                                label = { Text("Dashboard") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                icon = { Icon(Icons.Default.ListAlt, contentDescription = "Görevler") },
                                label = { Text("Görevler") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                icon = { Icon(Icons.Default.SmartToy, contentDescription = "Ajanlar") },
                                label = { Text("Ajanlar") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 3,
                                onClick = { selectedTab = 3 },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Ayarlar") },
                                label = { Text("Ayarlar") }
                            )
                        }
                    }
                ) { innerPadding ->
                    Surface(modifier = Modifier.padding(innerPadding)) {
                        when (selectedTab) {
                            0 -> DashboardScreen(vm)
                            1 -> TasksScreen(vm)
                            2 -> AgentsScreen(vm)
                            3 -> SettingsScreen(vm)
                        }
                    }
                }
            }
        }
    }
}
