package com.aioffice.mobile

import com.aioffice.mobile.data.local.ConnectionSettings
import com.aioffice.mobile.data.local.TaskEntity
import com.aioffice.mobile.domain.model.AgentType
import com.aioffice.mobile.domain.model.TaskPriority
import com.aioffice.mobile.domain.model.TaskStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class IdempotencyAndDomainTest {

    @Test
    fun `three agent architecture matches specification`() {
        val ids = AgentType.entries.map { it.id }
        assertEquals(listOf("claude_code", "codex", "openai"), ids)
    }

    @Test
    fun `each queued task generates unique idempotency key`() {
        val t1 = TaskEntity(
            title = "Roblox Obby Script",
            prompt = "Checkpoint sistemi yaz",
            agentId = AgentType.CLAUDE_CODE.id,
            priorityLevel = TaskPriority.HIGH.level,
            status = TaskStatus.WAITING.name
        )
        val t2 = TaskEntity(
            title = "Roblox Obby Script",
            prompt = "Checkpoint sistemi yaz",
            agentId = AgentType.CLAUDE_CODE.id,
            priorityLevel = TaskPriority.HIGH.level,
            status = TaskStatus.WAITING.name
        )
        assertNotEquals(t1.idempotencyKey, t2.idempotencyKey)
    }

    @Test
    fun `base url builder formats host and port cleanly`() {
        val settings = ConnectionSettings(host = " 192.168.1.42 ", port = 8787, useHttps = false)
        assertEquals("http://192.168.1.42:8787/", settings.buildBaseUrl())
    }
}
