#!/data/data/com.termux/files/usr/bin/bash
echo "AI OFFICE Android v0.3.0 - Telefonda (Termux) Derleme Betigi"
pkg update -y && pkg install -y openjdk-17 gradle wget unzip
gradle assembleDebug --no-daemon
echo "APK hazir: app/build/outputs/apk/debug/app-debug.apk"
