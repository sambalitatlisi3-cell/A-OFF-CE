# AI OFFICE Android v0.3.0 — Kurulum ve Mimari Belgesi

## 1. Proje İçeriği
- **Paket Adı:** `com.aioffice.mobile` (Min SDK 26 / Android 8.0, Target SDK 35)
- **Mimari:** MVVM + Repository Pattern + Kotlin Coroutines + StateFlow + Jetpack Compose + Room + DataStore + EncryptedSharedPreferences + Retrofit/OkHttp
- **3 Ajanlı Yapı:** `CLAUDE CODE` (Luau/Roblox), `CODEX` (UI/Modelleme/Büyük Proje), `OPENAI` (Hata Tespiti/Analiz/QA)
- **Çevrimdışı Kuyruk & Idempotency:** PC kapalıyken oluşturulan görevler `WAITING` durumuyla yerel Room veritabanında saklanır. Her görevin benzersiz `idempotencyKey` değeri vardır; PC tekrar çevrimiçi olduğunda görevler tekil olarak senkronize edilir.

## 2. APK Derleme ve Telefona Yükleme
1. Windows bilgisayarınızda **Android Studio**'yu açın ve bu klasörü (`AI_OFFICE_Android_v0.3.0`) proje olarak seçin (veya Gradle kuruluysa `BUILD_APK_WINDOWS.bat` dosyasını çalıştırın).
2. **Build > Build Bundle(s) / APK(s) > Build APK(s)** menüsüne tıklayın.
3. Oluşan `app/build/outputs/apk/debug/app-debug.apk` dosyasını telefonunuza aktarın ve dokunarak kurun.

## 3. Windows Bilgisayar Bağlantısı
1. Klasör içindeki `windows_coordinator_bridge/ai_office_bridge.py` dosyasını Windows PC'nizde çalıştırın (`pip install fastapi uvicorn pydantic httpx && python ai_office_bridge.py`).
2. Android uygulamasında **Ayarlar** sekmesine girip Windows PC'nizin yerel IP adresini (örn. `192.168.1.35`) ve portu (`8787`) kaydedip **Kaydet & Test Et** butonuna basın.
